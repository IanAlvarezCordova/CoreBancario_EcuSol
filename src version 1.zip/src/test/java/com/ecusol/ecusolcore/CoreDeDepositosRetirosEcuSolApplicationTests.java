package com.ecusol.ecusolcore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreDeDepositosRetirosEcuSolApplicationTests {

	@Test
	void contextLoads() {
	}

}
