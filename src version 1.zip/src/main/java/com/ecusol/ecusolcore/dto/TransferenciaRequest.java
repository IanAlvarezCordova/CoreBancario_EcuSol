package com.ecusol.ecusolcore.dto;

import java.math.BigDecimal;

// dto/TransferenciaRequest.java
public record TransferenciaRequest(
        String numeroCuentaOrigen,
        String numeroCuentaDestino,
        BigDecimal monto,
        String descripcion
) {}