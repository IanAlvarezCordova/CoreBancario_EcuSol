package com.ecusol.ecusolcore.dto;

import java.math.BigDecimal;

public record OperacionRequest(
        String numeroCuentaOrigen,
        String numeroCuentaDestino,  // null si es depósito/retiro
        BigDecimal monto,
        String descripcion

) {}