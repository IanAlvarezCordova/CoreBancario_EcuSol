// servicio/TransaccionService.java
package com.ecusol.ecusolcore.servicio;

import com.ecusol.ecusolcore.core.modelo.Cuenta;
import com.ecusol.ecusolcore.core.modelo.Movimiento;
import com.ecusol.ecusolcore.core.modelo.Transaccion;
import com.ecusol.ecusolcore.core.repositorio.CuentaRepository;
import com.ecusol.ecusolcore.core.repositorio.MovimientoRepository;
import com.ecusol.ecusolcore.core.repositorio.SucursalRepository;
import com.ecusol.ecusolcore.core.repositorio.TransaccionRepository;
import com.ecusol.ecusolcore.dto.OperacionRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class TransaccionService {

    @Autowired private CuentaRepository cuentaRepo;
    @Autowired private TransaccionRepository transRepo;
    @Autowired private MovimientoRepository movRepo;
    @Autowired private SucursalRepository sucursalRepo;

    @Transactional
    public String ejecutarOperacion(OperacionRequest req, String tipo, String canal, Long clienteId, Long sucursalId) {
        Transaccion trans = new Transaccion();
        trans.setTipo(tipo);
        trans.setCanal(canal);
        trans.setMonto(req.monto());
        trans.setDescripcion(req.descripcion());
        trans.setSucursalId(sucursalId);

        // REFERENCIA INTELIGENTE
        String nombreSucursal = "DESCONOCIDA";
        if ("CAJERO".equals(canal) && sucursalId != null) {
            nombreSucursal = sucursalRepo.findById(sucursalId)
                    .map(s -> s.getNombre().toUpperCase().replace(" ", "_"))
                    .orElse("CAJERO_" + sucursalId);
        }
        trans.setReferencia(tipo + "-" + ("CAJERO".equals(canal) ? nombreSucursal : "WEB") + "-" + System.currentTimeMillis());

        // GUARDAR TRANSACCIÓN PRIMERO (para tener ID)
        transRepo.save(trans);

        if (tipo.equals("TRANSFERENCIA")) {
            Cuenta origen = cuentaRepo.findByNumeroCuenta(req.numeroCuentaOrigen())
                    .orElseThrow(() -> new RuntimeException("Cuenta origen no encontrada"));
            Cuenta destino = cuentaRepo.findByNumeroCuenta(req.numeroCuentaDestino())
                    .orElseThrow(() -> new RuntimeException("Cuenta destino no encontrada"));

            if (clienteId != null && !origen.getClientePersonaId().equals(clienteId)) {
                throw new RuntimeException("No autorizado");
            }
            if (origen.getSaldo().compareTo(req.monto()) < 0) throw new RuntimeException("Saldo insuficiente");

            trans.setCuentaOrigenId(origen.getCuentaId());
            trans.setCuentaDestinoId(destino.getCuentaId());
            crearMovimientos(trans, origen, destino, req.monto());

        } else if (tipo.equals("DEPOSITO")) {
            // EN DEPÓSITO: el dinero entra a numeroCuentaDestino
            Cuenta destino = cuentaRepo.findByNumeroCuenta(req.numeroCuentaOrigen())  // ← ahora origen = la cuenta que recibe
                    .orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));
            trans.setCuentaDestinoId(destino.getCuentaId());
            crearMovimiento(trans, destino, "C", req.monto());

        } else if (tipo.equals("RETIRO")) {
            // EN RETIRO: el dinero sale de numeroCuentaOrigen
            Cuenta origen = cuentaRepo.findByNumeroCuenta(req.numeroCuentaOrigen())
                    .orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));
            if (origen.getSaldo().compareTo(req.monto()) < 0) throw new RuntimeException("Saldo insuficiente");
            trans.setCuentaOrigenId(origen.getCuentaId());
            crearMovimiento(trans, origen, "D", req.monto());
        }

        transRepo.save(trans); // actualiza si cambió origen/destino
        return "Operación exitosa - Ref: " + trans.getReferencia();
    }

    private void crearMovimientos(Transaccion t, Cuenta origen, Cuenta destino, BigDecimal monto) {
        crearMovimiento(t, origen, "D", monto);
        crearMovimiento(t, destino, "C", monto);
    }

    private void crearMovimiento(Transaccion t, Cuenta c, String tipo, BigDecimal monto) {
        BigDecimal anterior = c.getSaldo();
        BigDecimal nuevo = tipo.equals("C") ? anterior.add(monto) : anterior.subtract(monto);

        Movimiento m = new Movimiento();
        m.setTransaccionId(t.getTransaccion_id());
        m.setCuentaId(c.getCuentaId());
        m.setTipoMovimiento(tipo);
        m.setMonto(monto);
        m.setSaldoAnterior(anterior);
        m.setSaldoNuevo(nuevo);
        movRepo.save(m);
    }
}