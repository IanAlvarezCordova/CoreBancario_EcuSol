// servicio/CuentaService.java
package com.ecusol.ecusolcore.servicio;

import com.ecusol.ecusolcore.dto.CuentaDTO;
import com.ecusol.ecusolcore.dto.MovimientoDTO;
import com.ecusol.ecusolcore.core.modelo.Cuenta;
import com.ecusol.ecusolcore.core.repositorio.CuentaRepository;
import com.ecusol.ecusolcore.core.repositorio.MovimientoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CuentaService {

    @Autowired
    private CuentaRepository cuentaRepo;

    @Autowired
    private MovimientoRepository movimientoRepo;



    public List<CuentaDTO> obtenerMisCuentas(Long clienteId) {
        return cuentaRepo.findByClientePersonaId(clienteId).stream()
                .map(c -> new CuentaDTO(
                        c.getCuentaId(),
                        c.getNumeroCuenta(),
                        c.getSaldo(),
                        c.getEstado(),
                        c.getTipoCuentaId()   // ← perfecto
                ))
                .toList();
    }

    public boolean validarCuentaDeUsuario(String numeroCuenta, Long clienteId) {
        return cuentaRepo.findByNumeroCuenta(numeroCuenta)
                .map(cuenta -> cuenta.getClientePersonaId().equals(clienteId))
                .orElse(false);
    }

    public List<MovimientoDTO> obtenerMovimientos(String numeroCuenta) {
        Cuenta cuenta = cuentaRepo.findByNumeroCuenta(numeroCuenta)
                .orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));

        return movimientoRepo.findByCuentaIdOrderByFechaDesc(cuenta.getCuentaId()).stream()
                .map(m -> new MovimientoDTO(
                        m.getFecha(),
                        m.getTipoMovimiento(),
                        m.getMonto(),
                        m.getSaldoNuevo()
                ))
                .collect(Collectors.toList());
    }
}
