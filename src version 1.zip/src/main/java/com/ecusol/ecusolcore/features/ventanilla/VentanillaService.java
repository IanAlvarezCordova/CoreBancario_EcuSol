package com.ecusol.ecusolcore.features.ventanilla;

public class VentanillaService {
}
