package com.ecusol.ecusolcore.features.auth.dto;

public record JwtResponse(String token) {}