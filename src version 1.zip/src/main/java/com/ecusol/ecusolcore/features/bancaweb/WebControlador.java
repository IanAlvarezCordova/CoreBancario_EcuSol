// controlador/web/BancaWebControlador.java
package com.ecusol.ecusolcore.features.bancaweb;

import com.ecusol.ecusolcore.dto.*;
import com.ecusol.ecusolcore.servicio.CuentaService;
import com.ecusol.ecusolcore.servicio.TransaccionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/web")
public class WebControlador {

    @Autowired private CuentaService cuentaService;
    @Autowired private TransaccionService transaccionService;

    // ← CAMBIO AQUÍ: Long clienteId en vez de ClientePersona
    @GetMapping("/cuentas")
    public List<CuentaDTO> misCuentas(@AuthenticationPrincipal Long clienteId) {
        return cuentaService.obtenerMisCuentas(clienteId);
    }

    // ← CAMBIO AQUÍ también
    @PostMapping("/transferir")
    public String transferir(@AuthenticationPrincipal Long clienteId,
                             @RequestBody OperacionRequest req) {
        return transaccionService.ejecutarOperacion(req, "TRANSFERENCIA", "WEB", clienteId, null);
    }

    // ← NUEVO ENDPOINT DE MOVIMIENTOS (perfecto y seguro)
    @GetMapping("/movimientos/{numeroCuenta}")
    public List<MovimientoDTO> movimientos(@PathVariable String numeroCuenta,
                                           @AuthenticationPrincipal Long clienteId) {
        // Validamos que la cuenta sea del usuario
        if (!cuentaService.validarCuentaDeUsuario(numeroCuenta, clienteId)) {
            throw new RuntimeException("Cuenta no pertenece al usuario");
        }
        return cuentaService.obtenerMovimientos(numeroCuenta);
    }
}