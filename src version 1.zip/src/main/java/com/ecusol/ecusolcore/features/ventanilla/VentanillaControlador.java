// controlador/cajero/CajeroControlador.java
package com.ecusol.ecusolcore.features.ventanilla;

import com.ecusol.ecusolcore.dto.OperacionRequest;
import com.ecusol.ecusolcore.servicio.TransaccionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cajero")
public class VentanillaControlador {

    @Autowired private TransaccionService transaccionService;

    @PostMapping("/deposito")
    public String deposito(@RequestBody OperacionRequest req, @RequestParam Long sucursalId) {
        // Para depósito: el cliente indica su cuenta (origen) y mete plata
        if (req.numeroCuentaOrigen() == null || req.numeroCuentaOrigen().isBlank()) {
            throw new RuntimeException("numeroCuentaOrigen es obligatorio para depósito en cajero");
        }
        OperacionRequest fixedReq = new OperacionRequest(
                req.numeroCuentaOrigen(),
                null,  // destino no se usa en depósito
                req.monto(),
                req.descripcion()
        );
        return transaccionService.ejecutarOperacion(fixedReq, "DEPOSITO", "CAJERO", null, sucursalId);
    }

    @PostMapping("/retiro")
    public String retiro(@RequestBody OperacionRequest req, @RequestParam Long sucursalId) {
        if (req.numeroCuentaOrigen() == null || req.numeroCuentaOrigen().isBlank()) {
            throw new RuntimeException("numeroCuentaOrigen es obligatorio para retiro en cajero");
        }
        OperacionRequest fixedReq = new OperacionRequest(
                req.numeroCuentaOrigen(),
                null,
                req.monto(),
                req.descripcion()
        );
        return transaccionService.ejecutarOperacion(fixedReq, "RETIRO", "CAJERO", null, sucursalId);
    }
}