// servicio/AuthService.java
package com.ecusol.ecusolcore.features.auth;

import com.ecusol.ecusolcore.config.JwtTokenProvider;
import com.ecusol.ecusolcore.features.auth.dto.LoginRequest;
import com.ecusol.ecusolcore.features.auth.dto.RegisterRequest;
import com.ecusol.ecusolcore.core.modelo.ClientePersona;
import com.ecusol.ecusolcore.core.repositorio.ClientePersonaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private ClientePersonaRepository clienteRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    public String register(RegisterRequest req) {
        if (clienteRepo.existsByUsuario(req.usuario())) {
            throw new RuntimeException("Usuario ya existe");
        }
        if (clienteRepo.existsByEmail(req.email())) {
            throw new RuntimeException("Email ya registrado");
        }

        ClientePersona cliente = ClientePersona.builder()
                .cedula(req.cedula())
                .nombres(req.nombres())
                .apellidos(req.apellidos())
                .email(req.email())
                .telefono(req.telefono())
                .direccion(req.direccion())
                .usuario(req.usuario())
                .passwordHash(passwordEncoder.encode(req.password()))
                .entidadId(1L)
                .estado("ACTIVO")
                .build();

        clienteRepo.save(cliente);
        return "Cliente registrado con éxito - ID: " + cliente.getClienteId();
    }

    public String login(LoginRequest req) {
        ClientePersona cliente = clienteRepo.findByUsuario(req.usuario())
                            .orElseThrow(() -> new RuntimeException("Credenciales inválidas"));

        if (!passwordEncoder.matches(req.password(), cliente.getPasswordHash())) {
            throw new RuntimeException("Credenciales inválidas");
        }

        return jwtTokenProvider.createToken(cliente.getUsuario(), cliente.getClienteId());
    }
}