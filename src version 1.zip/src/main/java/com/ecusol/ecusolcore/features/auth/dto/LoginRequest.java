package com.ecusol.ecusolcore.features.auth.dto;

public record LoginRequest(String usuario, String password) {}